---
title: "Home"
hero_eyebrow: "Personal history · Brevard County, Florida"
hero_heading: "Someday, someone will wish they'd asked."
hero_prompts:
  - "What's the bravest thing you ever did, and did anyone know at the time?"
  - "Tell me about the house you grew up in. Start at the front door."
  - "Who did you love before you understood what love was?"
  - "What did a Sunday smell like when you were ten?"
  - "What did you believe at twenty that you'd argue with now?"
  - "Describe the moment you knew your whole life had just changed."
hero_sub: "We're a legacy storytelling studio on the Space Coast. We help families capture a parent, a grandparent, a whole life, in their own voice, and turn it into something you can hold."
hero_cta1: "See legacy books"
hero_cta2: "Shop the card kits"

offerings_heading: "Start small, or go all in."
offerings_sub: "However you begin, the point is the same: get the story down before it's only half-remembered."
offerings:
  - num: "Kit"
    title: "Tell Me Your Story cards"
    body: "A deck of the questions people wish they'd asked. Pull one out at Sunday dinner and watch what happens. The easiest place to start."
    url: "/card-kits"
    link_text: "See the card kits"
  - num: "Class"
    title: "Storytelling workshops"
    body: "Guided sessions for senior communities, libraries, and groups. People come for the prompts and stay for each other's stories."
    url: "/services"
    link_text: "Bring a workshop in"
  - num: "Book"
    title: "Legacy & memorial books"
    body: "We interview, we write, we design. You get a real book with your family's story in it, from a short keepsake to a full hardcover life."
    url: "/services"
    link_text: "Explore legacy books"

why_quote: "A person is a library. When they go, the building doesn't just close. It burns."
why_body: "Most of what made someone who they were lives in stories nobody's written down. The recipe and the reason behind it. The job they almost took. The war, the move, the marriage, the thing they never told the kids. We're here so that none of it has to be lost, and so that asking feels like a gift instead of a chore."

how_heading: "You talk. We do the rest."
how_sub: "You don't need to be a writer. You don't even need to know where to start. That's our job."
steps:
  - title: "We meet and listen"
    body: "A relaxed conversation to learn who the book is for and what matters most. No homework, no pressure."
  - title: "We interview"
    body: "Recorded sessions, in person or by phone, on your schedule. We ask the good questions and follow where the story goes."
  - title: "We write and design"
    body: "We shape the transcripts into clean, readable chapters, add the photos, and lay it all out with care."
  - title: "You hold the book"
    body: "You review, we revise, and then it's printed and in your hands, ready to pass down."

demo_heading: "See what one looks like."
demo_body: "Sometimes the easiest way to explain a legacy book is to hand you one. We keep a sample on hand, a full life told in a client's own words, so you can feel the weight of it before you commit to anything."

b2b_heading: "Bring storytelling to your community."
b2b_body: "We run warm, easy storytelling sessions for assisted living and senior communities across Brevard. Residents light up, families get keepsakes, and your activity calendar gets something with real heart in it. The first class is free so you can see how the room responds."

cta_heading: "The stories don't survive by accident."
cta_body: "Tell us who you're trying to remember. We'll tell you the simplest way to start."
---
